‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿୨ ♡ ୧‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿

# ‿︵‿︵‿︵‿︵‿︵‿୨ Introduction ୧‿︵‿︵‿︵‿︵‿︵‿


### --- **Thank you for downloading Melody's Cute Girl Illagers!** ---

#### This pack features pillagers, evokers, vindicators and illusions. It also supports several mods. Previously part of Melody's Cute Girl Villagers but has been branched into it's own pack, it's best to use both packs together.

#### - Suggestions, input, and bug reports are highly appreciated. I really want to know what you guys think so let me know on my discord server!

#### [**♡ Discord**](https://discord.gg/Qvuf4Wrw6H)
#### [**♡ Website**](https://melodymews.com/?utm_source=readmepillagersjan2026&utm_medium=readmepillagersjan2026&utm_campaign=readmepillagersjan2026&utm_term=readmepillagersjan2026)

> [!IMPORTANT]
> You need either:

> OptiFine 1.19.2 HD U I1 to OptiFine 1.21.2 for this resource pack to work. It WILL NOT WORK on OptiFine versions 1.21.3 or higher!
> OR
> [EMF] Entity Model Features mod and ETF. (entity culling is recommended too).

> If the illagers look broken... then there is likely another conflicting texture pack (two illager textures are overlapping each other from different packs)! To fix this just delete all illager (vindicator, pillager, evoker, illusioner) files and folders from the other/conflicting pack.
-- Note: You can rename "pack.png" to something else and rename "pack2.png" to "pack.png" to have a different pack icon.

> [Recommended]
> I prefer to use this pack with "Mizuno's 16 Craft Resource Pack".
> The preferred shaders are "Sildur’s Shaders" in the overworld/nether and "Complementary Shaders Reimagined" in the end and nether world.


# ‿︵‿︵‿︵‿︵‿︵‿୨ Updates ୧‿︵‿︵‿︵‿︵‿︵‿

## ♡ 03/03/2026 v1.0.1
# • Updated supported formats in pack.meta file.

## ♡ 10/01/2026 v1.0.0
# • Separated Illagers and Witches into their own packs.
# • Added partial mod support for "It Takes A Pillage" mod.
# • Altered Pillager uv boxes positons to make space for new boxes.
# • Fixed sitting skirt animation for pillager.


# ‿︵‿︵‿︵‿︵‿︵‿୨ Licensing ୧‿︵‿︵‿︵‿︵‿︵‿

### • Do not resell this pack or its files.
### • Do not redistribute this pack or its files.
### • You are allowed to edit the pack only for personal use and not commercial.
### • You are allowed to stream, screenshot, and make videos with this pack but give credit to me.
### • Keep it wholesome. Don’t use or edit this pack to show gore, torture, or NSFW content. No nudity, fetish/erotic content, or sexualized depictions of minors/age-ambiguous characters.
### • Use is prohibited for anyone who has engaged in harassment, hate speech, doxxing, cheating, or other malicious conduct toward me or my community, or whose name appears on my blocklist.
### • These rules are subject to change at any time.



# ‿︵‿︵‿୨ Current Supported Modded Professions ୧‿︵‿︵‿

- Updated: 10/01/2026

• 01. It Takes a Pillage (https://www.curseforge.com/minecraft/mc-mods/it-takes-a-pillage)
• 02. Shiny Mobs! (https://www.curseforge.com/minecraft/mc-mods/shiny)


# ‿︵‿︵‿୨ Pack Version Info ୧‿︵‿︵‿
• To remove the warning on the resource pack when you try to enable it, refer to the table below and change the "pack_format" value in the "pack.mcmeta" file to value associated to the version you're using:
• Refer to this page for the newer versions: https://Minecraft.fandom.com/wiki/Pack_format

[ Value |    Version  ]
[   9   | 1.19–1.19.2 ]
[   12  |   1.19.3    ]
[   13  |   1.19.4    ]
[   15  | 1.20–1.20.1 ]
[   18  |   1.20.2    ]
[   22  |1.20.3-1.20.4]
[   32  |   1.20.5    ]
[   34  |   1.21.-    ]


# ‿︵‿︵‿︵‿︵‿︵‿୨ Clarification ୧‿︵‿︵‿︵‿︵‿︵‿

### - I have heavily worked on, optimized, separated, and redid, all the textures/files/models/scripts since 2022, sketching ideas and physically working on this project to bring more variety of villagers and enhance them.
### - The original base model creator for the pack is said to have abandoned this pack and the Java porters struck out the "do not distribute" text as shown below and stated editing is allowed with credit given which I have done.

 ![Java port pack license](https://i.imgur.com/wFpF9Zk.png)


# ‿︵‿︵‿︵‿︵‿︵‿୨ Credits ୧‿︵‿︵‿︵‿︵‿︵‿


--- Credit to **_jx** & Cute Mob Models Resource pack for the original models ---


︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵
