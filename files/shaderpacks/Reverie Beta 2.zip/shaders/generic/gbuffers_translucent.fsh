#ifndef VOXY_TERRAIN
    in Data {
        vec2 lmcoord;
        vec2 texcoord;
        vec4 glcolor;
        flat uint Material;
        flat mat3 TBN;
        vec3 ViewPos;
    } DataIn;
#else
    struct Data {
        vec2 lmcoord;
        vec2 texcoord;
        vec4 glcolor;
        uint Material;
        mat3 TBN;
        vec3 ViewPos;
    } DataIn;
    void map_voxy_param_to_varying(VoxyFragmentParameters param) {
        DataIn.texcoord = param.uv;
        DataIn.lmcoord = param.lightMap;
        DataIn.lmcoord = max(DataIn.lmcoord * 1.06667 - 0.0648, 0);
        DataIn.Material = uint(param.customId - 10000.0);
        DataIn.glcolor = param.tinting;
        DataIn.ViewPos = screen_view(vec3(DataIn.texcoord, gl_FragCoord.z), true, false);
        // from Cortex
        vec3 normal = vec3(
                        uint((param.face >> 1) == 2),
                        uint((param.face >> 1) == 0),
                        uint((param.face >> 1) == 1)
                    ) *
            (float(int(param.face) & 1) * 2.0 - 1.0);
        DataIn.TBN = tbn_normal(player_view(normal, true));
    }
#endif

/* RENDERTARGETS:0,1,2,5 */

layout(location = 0) out vec4 Albedo;
layout(location = 1) out vec4 buf1;
layout(location = 2) out vec4 buf2;
layout(location = 3) out vec4 Shadow;

#ifdef VOXY_TERRAIN
    void init_frag_translucent(VoxyFragmentParameters param) {
#else
    void init_frag_translucent() {
#endif
    vec3 ScreenPos = gl_FragCoord.xyz * vec3(resolutionInv, 1);
    #if (defined DH_TERRAIN) || (defined VOXY_TERRAIN)
        bool IsDH = true;
    #else
        bool IsDH = false;
    #endif
    Positions Pos = get_positions(ScreenPos.xy, ScreenPos.z, IsDH, false);

    #if (defined DISTANT_HORIZONS) && (!defined VOXY)
        float Dither = bayer8(gl_FragCoord.xy);
        if (transition_to_dh(Pos.Player, Dither)) {
            discard;
            return;
        }
        #ifdef DH_TERRAIN
            float Depth = texture(depthtex0, ScreenPos.xy).x;
            if(Depth < 1) {
                discard; return;
            }
        #endif

        #if (defined DH_NOISE) && (defined DH_TERRAIN)
            Albedo.rgb = dh_noise(Pos.Player, Albedo.rgb);
        #endif
    #endif
    
    #ifndef GBUFFERS_BASIC
        #ifdef VOXY_TERRAIN
            Albedo = DataIn.glcolor * param.sampledColour;
        #else
            Albedo = DataIn.glcolor * texture(gtexture, DataIn.texcoord);
        #endif
    #else
        Albedo = glcolor_flat;
    #endif

    if(Albedo.a < 0.0001) {
        discard;
    }

    Albedo.rgb = srgb_linear(Albedo.rgb);

    Albedo.rgb *= texture(normals, DataIn.texcoord).b;

    #ifdef GBUFFERS_ENTITIES
    Albedo.rgb = mix(Albedo.rgb, entityColor.rgb, entityColor.a);
    #endif

    if (DataIn.Material == MATERIAL_WATER) {
        Albedo = vec4(0);
    }

    buf1.x = packUnorm2x8(Albedo.rg);
    buf1.y = packUnorm2x8(vec2(Albedo.b, float(DataIn.Material) / 255));

    buf1.z = packUnorm2x8(texture(specular, DataIn.texcoord).rg);

    vec3 Normal = DataIn.TBN[2];

    if(DataIn.Material != MATERIAL_WATER) {
        vec3 PackNormal = get_normal(DataIn.texcoord, vec2(0), vec2(0));
        Normal = DataIn.TBN * PackNormal;
    }

    buf1.w = packUnorm2x8(encodeUnitVector(view_player(Normal, IsDH)) * 0.5 + 0.5);

    vec2 Lightmap = DataIn.lmcoord;
    if(Lightmap.y > 1 / 255.0)
        Lightmap += bayer8(gl_FragCoord.xy) / 255.0;

    buf2.x = packUnorm2x8(Lightmap);

    buf2.w = packUnorm2x8(encodeUnitVector(view_player(DataIn.TBN[2], IsDH)) * 0.5 + 0.5);

    float PackSSS = get_sss(DataIn.texcoord);
    float Emissiveness = get_emissiveness(DataIn.texcoord);

    if (DataIn.Material != MATERIAL_WATER) {
        Albedo.rgb = calc_lighting(Pos, IsDH, DataIn.texcoord, Albedo.rgb, DataIn.Material, PackSSS, Emissiveness, DataIn.lmcoord, Normal, DataIn.TBN[2], false, Shadow);
    }
    else {
        Shadow.r = get_shadow_unfiltered(Pos.Player, DataIn.TBN[2], DataIn.lmcoord.y);
    }
}
