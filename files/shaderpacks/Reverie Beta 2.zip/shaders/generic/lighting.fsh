#include "/generic/gtao.glsl"

vec3 filter_floodfill(sampler3D Sampler, vec3 PlayerPos, vec3 FragPos, vec3 FlatNormal) {
    vec3 Pos = FragPos / voxelDistance / vec3(2, 1, 2); 
    vec4 C = vec4(texture(Sampler, Pos, 0).rgb, 1); // Center

    return C.xyz;
}

vec3 calc_lighting(Positions Pos, bool IsDH, vec2 texcoord, vec3 Color, float Material, float PackSSS, float Emissiveness, vec2 Lightmap,
    vec3 Normal, vec3 FlatNormal, bool IsHand, out vec4 ShadowBuf) {

    if (Material >= MATERIAL_TALL_PLANT_LOWER && Material <= MATERIAL_SHORT_PLANT) {
        Normal = gbufferModelView[1].xyz; // upDirection
    }
    float NdotL = dot(sLightPosN, Normal);

    Lightmap = pow4(Lightmap);
    Lightmap.x += Emissiveness * float(Emissiveness < 1);
    vec3 LMColor = TorchlightColor;
    #if (defined COLORED_LIGHTS) && (!defined DH_TERRAIN) && (!defined VOXY_TERRAIN)
        vec3 PlayerPosAbs = get_voxel_pos(Pos.Player) + view_player(Normal, false) * 0.065;

        if(is_in_voxel_range(PlayerPosAbs)) {
            vec3 VoxelData;
            if(frameCounter % 2 == 1) {
                VoxelData = filter_floodfill(voxelImgSampler_a, Pos.Player, PlayerPosAbs, FlatNormal);
            } else {
                VoxelData = filter_floodfill(voxelImgSampler_b, Pos.Player, PlayerPosAbs, FlatNormal);
            }
            VoxelData *= 6;

            float Fade = shadow_fade(Pos.Player, voxelDistance);
            LMColor = mix(VoxelData.rgb, LMColor, Fade);
        }
    #endif


    #ifndef GBUFFERS_TERRAIN
        // Prevents a strange rare lightleak
        NdotL *= Lightmap.y;
    #endif

    #ifdef DIMENSION_OVERWORLD
    float NangUp = dot(gbufferModelView[1].xyz, Normal) * 0.5 + 0.5;
    float NangL = -view_player(Normal, true).x * 0.5 + 0.5;
    vec3 SunA = texture(image0Sampler, (vec2(NangL, NangUp) * 15 * resolutionInv)).rgb; // Value written in prepare, in the data buffer

    if(lightningBoltPosition.w > 0) {
        float VdotLi = 1 - min(1, distance(lightningBoltPosition.xz, Pos.Player.xz) * 0.0025);
        vec3 LiBPN = normalize((player_view(lightningBoltPosition.xyz, false) - Pos.View));
        float NdotLi = max(0, dot(Normal, LiBPN)) * 0.8 + 0.2;
        SunA += vec3(1) * NdotLi * pow4(VdotLi);
    }
    
    SunA = mix(MinLight, SunA, Lightmap.y);
    #elif defined DIMENSION_NETHER
    // Fake lighting, to make things look less flat
    float NdotU = dot(Normal, gbufferModelView[1].xyz);
    vec3 FakeLavaLight = TorchlightColor * 0.05 * (-NdotU * 0.5 + 0.5);
    vec3 FakeAmbientLight = fogColor.rgb * 0.2 * (NdotU * 0.5 + 0.5);
    vec3 SunA = MinLight * 2 + FakeAmbientLight + FakeLavaLight;
    #else
    vec3 SunA = srgb_linear(vec3(0.2, 0.1, 0.15));
    #endif

    vec3 OutColor = Color * (SunA + LMColor * Lightmap.x);

    float SSSS = PackSSS;
    if ((PackSSS < 64.0 / 255.0 || PackSSS == 0) && Lightmap.y > 0.1) {
        if (Material == MATERIAL_SSS_WEAK) SSSS = SSS_STRENGTH_WEAK;
        else if (Material >= MATERIAL_SSS_STRONG && Material <= MATERIAL_LEAVES) SSSS = SSS_STRENGTH_STRONG;
        else SSSS = 0;
    }
    bool DoSSS = SSSS > 0;

    vec3 SunDirect = vec3(0);
    bool IsMetal, IsHardcodedMetal;
    vec3 Shadow = vec3(0);
    if (NdotL > 0 || DoSSS) {
        Shadow = get_shadow(Pos.Player, Pos.View, IsDH, FlatNormal, Lightmap.y, DoSSS, ivec2(gl_FragCoord.xy));

        if (Shadow != vec3(0)) {
            vec3 LightColor;
            if (sunAngle < 0.5)
                LightColor = dataBuf.SunColor;
            else
                LightColor = dataBuf.MoonColor;

            float LHeight = sin(sunAngle * TAU); // to_player_pos(sunPosN).y;
            LightColor *= smoothstep(0.0, 0.05, abs(LHeight));

            SunDirect = Color / PI * max(0.1, float(!IsMetal));
            SunDirect *= LightColor * max(NdotL, 0);

            if (DoSSS) {
                SSSS = (1 - SSSS) * 5;

                float SSS = exp(-SSSS * abs(NdotL));
                float Phase = max(ISOTROPIC_PHASE, cs_phase(dot(Pos.ViewN, sLightPosN), 0.6));
                SunDirect += Color.rgb * LightColor * SSS * Phase;
            }
        }
    }
    OutColor = OutColor + SunDirect * Shadow;

    ShadowBuf.r = get_luminance(Shadow);
    ShadowBuf.gba = vec3(0);

    return OutColor * max(0., float(!IsMetal));
}
