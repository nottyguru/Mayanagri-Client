#include "/lib/all_the_libs.glsl"

out vec2 texcoord;

void main() {
	#ifdef SPATIAL_DENOISING
		gl_Position = ftransform();
		texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	#else
		gl_Position = vec4(-1);
	#endif
}
