#include "/lib/all_the_libs.glsl"
#define GBUFFERS_ENTITIES

#include "/generic/gbuffers.fsh"

void main() {
    init_frag();
}

