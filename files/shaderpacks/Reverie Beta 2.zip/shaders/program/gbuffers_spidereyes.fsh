#include "/lib/all_the_libs.glsl"

#define GBUFFERS_SPIDEREYES
#include "/generic/gbuffers.fsh"

void main() {
    init_frag();
}
