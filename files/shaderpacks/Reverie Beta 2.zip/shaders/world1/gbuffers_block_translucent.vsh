#version 460 compatibility
#define DIMENSION_END

#include "/program/gbuffers_block_translucent.vsh"